Folder specifications:
(1) ist: the source files for making the library of ist.lib.
(2) st: the demo program for using routines in ist.lib,
where readme.txt contains a brief specification.

The two projects were built by Microsoft VC++ 6.0.

For the source code of all the 3 inv-st algorithms we published
so far, see ist\ist.c. In the algorithms, we assume the sentinel
to be the smallest, instead of the largest in the published papers.

Pls. feel free to contact us if there is anything unclear, at:
issng@mail.sysu.edu.cn

01/Dec/2009