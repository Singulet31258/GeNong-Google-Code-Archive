#ifndef _IST_H_874375893653548774

int get_st(unsigned char *R, const unsigned char *T, int n, int k);
int get_ist(int algorithm, unsigned char *buffer);

#endif