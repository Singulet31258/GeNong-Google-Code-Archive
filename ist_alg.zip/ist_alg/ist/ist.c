//
//  IST.CPP
// 
//  Ge Nong
//  nong@ieee.org
// 
// DESCRIPTION
// -----------
//
//  This program performs an inverse limited order Burrows-Wheeler 
//  transform (inverse sort transform) on an input file and sends 
//  the result to an output file.
//
//  This program uses the framework of Mark Nelson's codes for BWT
//  at http://web2.airmail.net/markn.

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <fcntl.h>
#if !defined( unix )
#include <io.h>
#endif
#include <string.h>
#include <math.h>
#include <time.h>

void MakeD_nk(int n, int k, unsigned char *buffer, char *D, int *P, int *Q);
void MakeD_nlogk(int n, int k, char *D, int *P, int *Q);
void MakeD_n(int n, int k, unsigned char *buffer, char *D, int *P, int *Q);
void RestoreS(int n, unsigned char *buffer, char *D, int *P, int *Q);

int get_ist(int algorithm, unsigned char *buffer)
{
    int n, k, first, last;
    int i, j, sum;
    int Count[257], RunningTotal[257];
    unsigned char *S, *b1;
    int *P, *Q;

    b1 = buffer + sizeof(int);
    n = *((int *)buffer);
    first = *((int *)&b1[n]);
    last = *((int *)&b1[n+sizeof(int)]);
    k = *((int *)&b1[n+2*sizeof(int)]);

    if(algorithm==2 && pow(2, (int)(log(k)/log(2)+0.1))!=k)
        return -1;

    S = (unsigned char *)malloc((n+1)*sizeof(unsigned char));
    P = (int *)malloc(n*sizeof(int));
    Q = (int *)malloc(n*sizeof(int));

    if(!S || !P || !Q) 
    {
        free(S); free(P); free(Q);
        return -1;
    }

    for (i = 0; i < 257; i++)
        Count[i] = 0;
    for (i = 0; i < n; i++)
        if (i == last)
            Count[256]++;
        else
            Count[b1[i]]++;

    sum = Count[256];
    RunningTotal[256] = 0;
    Count[256] = 0;
    for (i = 0; i < 256; i++) {
        RunningTotal[i] = sum;
        sum += Count[i];
		    for(j=0; j<Count[i]; j++)
            S[RunningTotal[i]+j]=i;
        Count[i] = 0;
    }

    for (i = 0; i < n; i++) {
        int index;
        if (i == last)
            index = 256;
        else
            index = b1[i];
        Q[Count[index] + RunningTotal[index]] = i;
        Count[index]++;
    }

    for(i=0; i<n; i++)
		    P[Q[i]]=i;

    if(algorithm==1)
	    MakeD_nk(n, k, b1, (char *)S, P, Q);
    else
	    if(algorithm==2)
		    MakeD_nlogk(n, k, (char *)S, P, Q);
    else
	    if(algorithm==3)
		    MakeD_n(n, k, b1, (char *)S, P, Q);

    RestoreS(n, b1, (char *)S, P, Q);

    for(i=0; i<n-1; i++)
        buffer[i] = S[i];

    free(S); 
    free(P);
    free(Q);
    return 0;
}

void RestoreS(int n, unsigned char *buffer, char *D, int *P, int *Q)
{
    //initialize counter array C[1, n]$;
    // calculate the frequency and the
    // starting point of each context.
    int i, j;
    int *C, *T;
    unsigned char *S;
	
    C=P;
    T = (int *)malloc(n*sizeof(int));

    for(i=0; i<n; i++)
        C[i]=0;

    for(i=0; i<n; i++)
    {
       if(D[i]==1)
          j=i;
       T[Q[i]]=j;
       C[j]++;
    }
    // to restore S
    S = (unsigned char *)D;
    j=n-1;
    S[j]='?';
    j=0;
    for(i=n-2; i>=0; i--)
    {
        S[i]=buffer[j];
        if(i>0)
        {
          j=T[j];
          C[j]--;
          // update the index for
          // the next character
          j=j+C[j];
        }
    }

    free(T);
}

// compute the vector D with a time complexity O(nk)
// and a space complexity O(n).
void MakeD_nk(int n, int k, unsigned char *buffer, char *D, int *P, int *Q)
{
	int i, j;
	char odd;
	int *D0, *D1;

	D0 = (int *)malloc(n*sizeof(int));
	D1 = (int *)malloc(n*sizeof(int));

	for(i=0; i<n; i++)
	{
		D0[i]=buffer[i];
		D[i]=0;
	}
	//D0[Q[n-1]]=256;
  D0[Q[0]]=256;


	odd=1; D[0]=1; 
	for(i=0; i<k; i++)
	{
		for(j=0; j<n; j++)
			if(odd==1)
				D1[P[j]]=D0[j];
			else
				D0[P[j]]=D1[j];

		for(j=1; j<n; j++)
			if(odd==0 && D0[j]!=D0[j-1] ||
				odd==1 && D1[j]!=D1[j-1])
				D[j]=1;

		odd=1-odd;
	}

	free(D0);
	free(D1);
}

// compute the vector D with a time complexity O(nlogk)
// and a space complexity O(n).
void MakeD_nlogk(int n, int k, char *D, int *P, int *Q)
{
	int i, j, w;
  int loops, LastD0;
	char odd;
	int *D0, *D1, *H;
  unsigned char *S;

	D0 = (int *)malloc(n*sizeof(int));
	D1 = (int *)malloc(n*sizeof(int));
	H = (int *)malloc(n*sizeof(int));

  S = (unsigned char *)D;
	for(i=0; i<n; i++)
	{
		D0[i]=S[i]; //F[i];
		D[i]=0;
	}
	//D0[n-1]=256;
  D0[0]=256;

	loops=(int)(log(k)/log(2)+0.1);
	odd=1;
	for(i=0; i<loops; i++)
	{
		for(j=0; j<n; j++)
			if(odd==1)
			{ 
				D1[P[j]]=D0[j]; 
				H[j]=P[P[j]]; 
			}
			else
			{
				D1[H[j]]=D0[j]; 
				P[j]=H[H[j]];
			}

		for(j=0; j<n; j++)
		{
			if(j==0 || D0[j]!=LastD0 ||
				D1[j]!=D1[j-1])
			{
				LastD0=D0[j];
				w=j;
			}
			D0[j]=w;
		}
		
		odd=1-odd;
	}

	D[0]=1; 
	for(i=1; i<n; i++)
		if(D0[i]!=D0[i-1])
			D[i]=1;


	free(D0);
	free(D1);
  free(H);
}

void MakeXY(int n, int k, unsigned char *buffer, int *Q,
            int *X0, int *X1, int *Y)
{
  int i, j;
  int u, v, r, t;

  for(i=0; i<n; i++)
     Y[i]=-1;
  r=0; j=0; v=0; u=0; 
  for(i=0; i<n; i++)
  {
    if(Y[j]!=-1) // visited
    {
      for(t=0; t<u-1; t++)
			    X1[v+t]=u-1-t;
	    X1[v+u-1]=-(u-1);
	    v=v+u; u=0;
	    for(t=r+1; t<n; t++) // get next start point.
	    if(Y[t]==-1) // next unvisited
	    {
		    r=t; j=r;
		    break;
	    }
    }

    Y[j]=v+u; u++;
    //if(j==n-1)
    if(j==0)
 	    X0[Y[j]]=256;
	  else
	    X0[Y[j]]=buffer[Q[j]]; // =F[j]
	  j=Q[j];
  }
  if(u>0)
  {
	  for(t=0; t<u-1; t++)
		  X1[v+t]=u-1-t;
	  X1[v+u-1]=-(u-1);
  }

  return;
}

void GetCycle(int j, int *head, int *tail, int *cycle,
                     int *X1, int *Y)
{
	  // compute the tail of cycle
	  if(X1[Y[j]]>=0)
		  *tail=Y[j]+X1[Y[j]];
	  else
		  *tail=Y[j]; 

	  // compute the head of cycle
	  *head=*tail+X1[*tail]; 

	  // compute the length of cycle
	  *cycle=*tail-*head+1;
}

void GetSiteInCycle(int h, int j, int *head, int *tail, int *cycle, int *site, 
                           int *X1, int *Y)
{
	GetCycle(j, head, tail, cycle, X1, Y);
	if(h>0)
	{
		if(Y[j]==*tail)
			*site=(h-1)%*cycle+*head; 
		else
			if(h>=(X1[Y[j]]+1))
				*site=(h-(X1[Y[j]]+1))%*cycle+*head; 
			else
				*site=Y[j]+h;
	}
	else
		*site=Y[j]; 
}

void CyclicForward(int *site, int *X1)
{
	if(X1[*site]>0)
		(*site)++;
	else 
		*site=*site+X1[*site];
}

void GetLCPofTwoCycles(int *h, int cycle, int i, int j, 
                              int *X0, int *X1)
{
	int site[2];
	site[0]=i; site[1]=j;
	while(*h<cycle)
	{
		if(X0[site[0]]!=X0[site[1]])
			break;
		(*h)++;
		CyclicForward(site, X1);
		CyclicForward(site+1, X1);
	}
}

void MakeD_n(int n, int k, unsigned char *buffer, char *D, int *P, int *Q)
{
  int i, j;
  int h[2], r, t;
  int head[2], tail[2], cycle[2], site[2];
  int *X0, *X1, *Y;
  char diff;

  X0 = (int *)malloc(n*sizeof(int));
  X1 = (int *)malloc(n*sizeof(int));
  Y = (int *)malloc(n*sizeof(int));

  MakeXY(n, k, buffer, Q, X0, X1, Y);

  for(i=0; i<n; i++)
  {
    GetCycle(i, head, tail, cycle, X1, Y);
    if(*cycle<=k/2)
	    D[i]=-2; // mark out cycles not longer than k/2
    else
	    D[i]=-1;
  }

  // compute D for cycles longer than k/2
  r=-1; j=r;
  h[0]=0; h[1]=0;
  for(i=0; i<n; i++)
  {
    if(j==r) // complete a loop
    {
	    for(t=r+1; t<n; t++) // get next start point.
	     if(D[t]==-1) // next unvisited cycles not shorter than k
		    break;
	    if(t>=n)
		    break;
	    r=t; j=r;
	    h[0]=0; h[1]=0;
    }

    for(t=0; t<2; t++)
    {
	    GetSiteInCycle(h[t], j, head, tail, cycle, site, X1, Y);
	    if(t==0)
	    {
		    if(j>0)
		    {
			    GetSiteInCycle(h[t], j-1, head+1, tail+1, cycle+1, site+1, X1, Y);
			    GetLCPofTwoCycles(h+t, k, site[0], site[1], X0, X1);
		    }
		    else
			    h[t]=0;
	    }
	    else
	    {
		    if(j<n-1)
		    {
			    GetSiteInCycle(h[t], j+1, head+1, tail+1, cycle+1, site+1, X1, Y);
			    GetLCPofTwoCycles(h+t, k, site[0], site[1], X0, X1);
		    }
		    else
			    h[t]=0;
	    }
	    if(h[t]==k) 
		    D[j+t]=0;
	    else 
		    D[j+t]=1;
	    if(h[t]>0) 
		    h[t]--;
    }
    j=Q[j];
  }

  // compute D for cycles not longer than than k/2
  D[0]=1;
  for(i=1; i<n; i++)
  {
    if(D[i]>=0) // visited cycles
	    continue;
    j=i;
    GetSiteInCycle(0, j, head, tail, cycle, site, X1, Y);
    GetSiteInCycle(0, j-1, head+1, tail+1, cycle+1, site+1, X1, Y);

    // two cycles must be different if their lengths are not longer than k/2 and different
    if(cycle[0]!=cycle[1]) 
	    diff=1;
    else
    {
	    h[0]=0;
	    GetLCPofTwoCycles(h, cycle[0], site[0], site[1], X0, X1);
	    if(h[0]==cycle[0])
		    diff=0;
	    else
		    diff=1;
    }
    for(t=0; t<cycle[0]; t++)
    {
	    if(D[j]<0)
		    D[j]=diff;
	    j=Q[j];
    }
  }

  free(X0);
  free(X1);
  free(Y);
}
