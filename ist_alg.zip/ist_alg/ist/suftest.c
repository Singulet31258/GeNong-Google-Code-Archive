/*
 * suftest.c for sais-lite
 * Copyright (c) 2008-2009 Yuta Mori All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "sais.h"
#include <fcntl.h>
#if !defined( unix )
#include <io.h>
#endif

int get_st(unsigned char *R, const unsigned char *T, int n, int k);
int make_st(const unsigned char *T, int *SA, int n, int k);

/*
  T = (unsigned char)[n];
  R = (unsigned char)[n+1] + int[4];
*/
int
get_st(unsigned char *R, const unsigned char *T, int n, int k) {
  int n1, i, first, last;
  int *SA;
  unsigned char *R1;

  if(k <= 0 || k > n || !R || !T) 
    return -1;

  n1 = n + 1;
  SA = (int *)malloc((size_t)n1 * sizeof(int));

  if(!SA || sais(T, SA+1, (int)n) != 0)
  {
    free(SA);
    return -1;
  }

  SA[0] = n;
  make_st(T, SA, n1, k);

  /* Output the result */
  *((int *)R) = n1;
  R1 = R + sizeof(int);
  for (i = 0 ; i < n1 ; i++) {
    if (SA[i] == 1)
      first = i;
    if (SA[i] == 0) {
      last = i;
      R1[i] = '?';
    } else
      R1[i] = T[SA[i] - 1];
  }

  *((int *)&R1[n1]) = first;
  *((int *)&R1[n1+sizeof(int)]) = last;
  *((int *)&R1[n1+2*sizeof(int)]) = k;

  free(SA);
  return 0;
}

int
make_st(const unsigned char *T, int *SA, int n, int k) {
  char *D;
  int *P, *Q;
  int i, j;
  int h, r, u, v;

  // allocate space
  P = (int *)malloc((size_t)n * sizeof(int));
  Q = (int *)malloc((size_t)n * sizeof(int));
  D = (char *)calloc((size_t)n, sizeof(char));

  if(!P || !Q || !D || k<=0) {
    free(P);
    free(Q);
    free(D);
    return -1;
  }

  // compute inverse SA
  for(i = 0; i < n; i++)
    Q[SA[i]] = i;

  for(i = 0; i < n-1; i++)
    P[Q[i]] = Q[i+1];

  // compute the difference array D
  h = 0;
  r = Q[0];
  for(i = 0; i < n-1; i++) {
    for(; h < k; h++) {
      u = SA[r-1] + h;
      v = SA[r] + h;
      if(u >= n-1 || v >= n-1 || T[u] != T[v]) {
        h--;
        break;
      }
    }

    if(h<k) 
      D[r] = 1;

    h--;
    if(h < 0)
      h = 0;

    r = P[r];
  }
  D[0] = 1;

  // compute ST-k
  memset((char *)P, 0, (size_t)n * sizeof(int)); 
  
  j = 0;
  for(i = 0; i < n; i++) {
    if(!D[i])
      Q[SA[i]] = j;
    else
      j = i;
  }

  for(i = 0; i < n; i++) {
    SA[Q[i] + P[Q[i]]] = i;
    P[Q[i]]++;
  }

  // free allocated space
  free(P);
  free(Q);
  free(D);

  return 0;
}

