/*
 * st.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "ist.h"
#include <fcntl.h>
#if !defined( unix )
#include <io.h>
#endif

static
void
print_help(const char *progname, int status) {
  fprintf(stderr, "usage: %s order inputfile\n\n", progname);
  exit(status);
}

int
main(int argc, const char *argv[]) {
  FILE *fp;
  const char *fname;
  unsigned char *T, *R, *R1;
  long n, n1;
  clock_t start, finish;
  int i;
  int k_order, first, last;

  /* Check arguments. */
  if((argc == 1) ||
     (strcmp(argv[1], "-h") == 0) ||
     (strcmp(argv[1], "--help") == 0)) { print_help(argv[0], EXIT_SUCCESS); }
  if(argc < 3) { print_help(argv[0], EXIT_FAILURE); }

	// read the k_order value.
	k_order=0;
  if ( argc > 1 ) {
	  sscanf( argv[ 1 ], "%d", &k_order);
    argv++;
    argc--;
  }
	if ( k_order <= 0) {
		fprintf( stderr, "\nk_order must be >=1, exit!" );
		exit(0);
	}

  fprintf( stderr, "\nPerforming ST(%0d) on ", k_order);
  if ( argc > 1 ) {
      freopen( argv[ 1 ], "rb", stdin );
      fprintf( stderr, "%s", argv[ 1 ] );
  } else
      fprintf( stderr, "stdin" );

  fprintf( stderr, " to " );
  if ( argc > 2 ) {
      freopen( argv[ 2 ], "wb", stdout );
      fprintf( stderr, "%s", argv[ 2 ] );
  } else
      fprintf( stderr, "stdout" );
  fprintf( stderr, "\n" );

#if !defined( unix )
  setmode( fileno( stdin ), O_BINARY );
  setmode( fileno( stdout ), O_BINARY );
#endif

  /* Open a file for reading. */
  if((fp = fopen(fname = argv[1], "rb")) == NULL) {
    fprintf(stderr, "%s: Cannot open file `%s': ", argv[0], fname);
    perror(NULL);
    exit(EXIT_FAILURE);
  }

  /* Get the file size. */
  if(fseek(fp, 0, SEEK_END) == 0) {
    n = ftell(fp);
    rewind(fp);
    if(n < 0) {
      fprintf(stderr, "%s: Cannot ftell `%s': ", argv[0], fname);
      perror(NULL);
      exit(EXIT_FAILURE);
    }
  } else {
    fprintf(stderr, "%s: Cannot fseek `%s': ", argv[0], fname);
    perror(NULL);
    exit(EXIT_FAILURE);
  }

  /* Allocate 5n bytes of memory. */
  n1 = n + 1;
  T = (unsigned char *)malloc((size_t)n1 * sizeof(unsigned char));
  R = (unsigned char *)malloc((size_t)n1*sizeof(unsigned char) + 4*sizeof(int));
  if((T == NULL) || (R == NULL)) {
    fprintf(stderr, "%s: Cannot allocate memory.\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  /* Read n bytes of data. */
  if(fread(T, sizeof(unsigned char), (size_t)n, fp) != (size_t)n) {
    fprintf(stderr, "%s: %s `%s': ",
      argv[0],
      (ferror(fp) || !feof(fp)) ? "Cannot read from" : "Unexpected EOF in",
      argv[1]);
    perror(NULL);
    exit(EXIT_FAILURE);
  }
  fclose(fp);

  /* Compute the transform. */
  fprintf(stderr, "%s: %ld bytes ... ", fname, n);
  start = clock();
  if(get_st(R, T, n, k_order) != 0) {
    fprintf(stderr, "%s: Cannot allocate memory.\n", argv[0]);
    exit(EXIT_FAILURE);
  }
  finish = clock();
  fprintf(stderr, "%.4f sec\n", (double)(finish - start) / (double)CLOCKS_PER_SEC);

  /* Output the result */
  fprintf(stderr, "Outputing ST result: \n");

  R1 = R + sizeof(int);
  fwrite( (char *) &n1, 1, sizeof(n1), stdout );
  for (i = 0 ; i < n1 ; i++)
      fputc(R1[i], stdout);

  first = *((int *)&R1[n1]);
  last = *((int *)&R1[n1+sizeof(int)]);

  fwrite((char *) &first, 1, sizeof(first), stdout);
  fwrite((char *) &last, 1, sizeof(last), stdout);
  fwrite((char *) &k_order, 1, sizeof(k_order), stdout);

  /* Deallocate memory. */
  free(T);
  free(R);

  return 0;
}

