I. Files
ist.lib contains the functions for computing the forward and 
the backward sort transforms (STs), and ist.h is the header file
for these functions.

st.c: forward ST.
ist.c: backward ST, i.e. inverse ST.

II. Usages:
1. Forward transform 
st order inputfile [outputfile]

2. Backward transform
ist algorithm inputfile [outputfile]

where "algorithm" specifies which inverse algorithm is used,
its values can be one of {n, nlogk, nk}, and the default is n.

3. Example
To do an order-16 ST on file st.c and output to st.c.16:
st 16 st.c st.c.16

To invert st.c.16 to st.c.0:
ist st.c.16 st.c.0

Finally, to verify the transform is correct or not:
comp st.c.0 st.c

III. Others
The folder bwtcode contains the programs from 
Mark Nelson
http://web2.airmail.net/markn

You may refer to http://marknelson.us/1996/09/01/bwt/
for how to build your own compressor by using them
and replacing BWT with ST.

Enjoy!