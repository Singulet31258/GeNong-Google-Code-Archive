//
//  ist.c
// 
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <fcntl.h>
#if !defined( unix )
#include <io.h>
#endif
#include <string.h>
#include <math.h>
#include <time.h>
#include "ist.h"

main( int argc, char *argv[] )
{
    clock_t t_start, t_end;
    double t_len;
    unsigned char *buffer, *b1;
    int n, first, last, k_order;
    int debug, algorithm, i;

    debug = 0;
    algorithm = 3;

    if ( argc > 1 && strcmp( argv[ 1 ], "-d" ) == 0 ) {
        debug = 1;
        argv++;
        argc--;
    }
    if ( argc > 1 && (strcmp( argv[ 1 ], "nk" ) == 0 ||
		      strcmp( argv[ 1 ], "nlogk" ) == 0 || strcmp( argv[ 1 ], "n" ) == 0))
    {
		    if(strcmp( argv[ 1 ], "nlogk" ) == 0 ) 
		    	algorithm = 2;
		    else
		    	if(strcmp( argv[ 1 ], "n" ) == 0 ) 
				    algorithm = 3;

        argv++;
        argc--;
    }

    if(algorithm==1)
		    fprintf( stderr, "Performing Inverse ST-nk on " );
    else
		if(algorithm==2)
		    fprintf( stderr, "Performing Inverse ST-nlogk on " );
    else
		if(algorithm==3)
		    fprintf( stderr, "Performing Inverse ST-n on " );

    if ( argc > 1 ) {
        freopen( argv[ 1 ], "rb", stdin );
        fprintf( stderr, "%s", argv[ 1 ] );
    } else
        fprintf( stderr, "stdin" );
    fprintf( stderr, " to " );
    if ( argc > 2 ) {
        freopen( argv[ 2 ], "wb", stdout );
        fprintf( stderr, "%s", argv[ 2 ] );
    } else
        fprintf( stderr, "stdout" );
    fprintf( stderr, "\n" );

#if !defined( unix )
    setmode( fileno( stdin ), O_BINARY );
    setmode( fileno( stdout ), O_BINARY );
#endif

    t_start=clock();
    for ( ; ; ) {
        if (fread( (char *) &n, sizeof(n), 1, stdin ) == 0)
            break;
        fprintf(stderr, "Processing %ld bytes\n", n);

        buffer = (unsigned char *)malloc(n*sizeof(unsigned char) + 4*sizeof(int));
        b1 = buffer + sizeof(int);
        if(!buffer) 
        {
            free(buffer);
            fprintf( stderr, "No enough space, quit!\n" );
            abort();
        }

        if (fread( (char *)b1, 1, (size_t)n, stdin ) != (size_t)n) {
            fprintf( stderr, "Error reading data\n" );
            free(buffer);
            abort();
        }

        fread( (char *) &first, sizeof(first), 1, stdin );
        fread( (char *)&last, sizeof(last), 1, stdin );
        fread( (char *)&k_order, sizeof(k_order), 1, stdin );

		    if(algorithm==2 && pow(2, (int)(log(k_order)/log(2)+0.1))!=k_order)
		    {
		    	fprintf( stderr, "The order k must be a power of 2, exited!" );
          free(buffer);
		    	exit(1);
		    }

        *((int *)buffer) = n;
        *((int *)&b1[n]) = first;
        *((int *)&b1[n+sizeof(int)]) = last;
        *((int *)&b1[n+2*sizeof(int)]) = k_order;

        if(!get_ist(algorithm, buffer))
        {

	        for(i=0; i<n-1; i++)
            putc(buffer[i], stdout);

          fprintf(stderr, "The string has been restored.");
        }
        else
          fprintf(stderr, "Failed in inverting the transform!");


        free(buffer);
    }
    t_end=clock();
    t_len = (double)(t_end - t_start) / CLOCKS_PER_SEC;
    fprintf(stderr, "\nRunning time=%5.3lf(ms)", t_len*1000);

    return 1;
}


